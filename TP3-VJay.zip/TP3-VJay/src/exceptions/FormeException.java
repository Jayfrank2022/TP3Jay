package exceptions;

/**
 * Cette classe permet de personnaliser les exceptions associées aux formes
 *
 * @author Jérémy Marceau
 */
public class FormeException extends Exception {
    /**
     * Cette méthode gère l'exception avec un message d'erreur par défaut
     */
    public FormeException() {
        super("Erreur d'une classe forme");
    }

    /**
     * Cette méthode gère l'exception avec un message d'erreur personnalisé
     *
     * @param message : message d'erreur personnalisé
     */
    public FormeException(String message) {
        super(message);
    }
}
