package formes;

import exceptions.FormeException;

/**
 * Cette classe permet de gérer le cercle
 *
 * @author Jérémy Marceau
 */
public class Cercle extends Forme {

    /**
     * Rayon du cercle
     */
    private int rayon;

    /**
     * Constructeur de la classe Cercle
     *
     * @param rayon : le rayon du cercle
     * @throws FormeException : exception personnalisée Forme
     */
    public Cercle(int rayon) throws FormeException {
        super("Cercle");

        if (validerRayon(rayon)) {
            setRayon(rayon);
        } else {
            throw new FormeException("Paramètre invalide passé au constructeur de la classe Cercle");
        }
    }

    /**
     * Cette méthode permet de calculer le périmètre du cercle
     *
     * @return le périmètre du cercle
     */
    @Override
    public int calculerPerimetre() {
        return (int) (2 * Math.PI * this.rayon);
    }

    /**
     * Cette méthode permet de calculer la surface du cercle
     *
     * @return la surface du cercle
     */
    @Override
    public int calculerSurface() {
        return (int) (Math.PI * Math.pow(this.rayon, 2));
    }

    /**
     * Cette méthode permet d'obtenir le rayon du cercle
     *
     * @return le rayon du cercle
     */
    public int getRayon() {
        return this.rayon;
    }

    /**
     * Cette méthode permet d'assigner un rayon au cercle
     *
     * @param rayon : rayon d'un cercle
     */
    public void setRayon(int rayon) {
        if (validerRayon(rayon)) {
            this.rayon = rayon;
        }
    }

    /**
     * Cette classe permet de personnaliser les informations du cercle
     *
     * @return les informations personnalisées du cercke
     */
    @Override
    public String toString() {
        return this.toStringCourt() + " " + this.rayon;
    }

    /**
     * Cette méthode permet de valider un rayon de cercle
     *
     * @param rayon : rayon de cercle
     * @return le résultat de la validation de rayon de cercle
     */
    private static boolean validerRayon(int rayon) {
        return (rayon >= MIN_VAL && rayon <= MAX_VAL);
    }
}