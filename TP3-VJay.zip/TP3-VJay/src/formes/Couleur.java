package formes;

/**
 * Cette Enum permet de gérer les couleurs
 *
 * @author Jérémy Marceau
 */
public enum Couleur {
    /**
     * Liste des éléments de l'Enum Couleur
     */
    ROUGE("rouge"), VERT("vert"), BLEU("bleu"), JAUNE("jaune"), NOIR("noir"), ORANGE("orange");

    /**
     * Nom de la couleur
     */
    private String nom;

    /**
     * Constructeur de l'Enum Couleur
     *
     * @param nom : le nom de la couleur
     */
    Couleur(String nom) {
        setNom(nom);
    }

    /**
     * Cette méthode permet d'obtenir le nom de la couleur
     *
     * @return le nom de la couleur
     */
    public String getNom() {
        return this.nom;
    }

    /**
     * Cette méthode permet d'assigner un nom à la couleur
     *
     * @param nom : nom de la couleur
     */
    private void setNom(String nom) {
        this.nom = nom;
    }

    /**
     * Cette méthode permet de personnaliser l'information de la couleur
     *
     * @return l'information personnalisée de la couleur
     */
    @Override
    public String toString() {
        return this.nom;
    }

}