package formes;

/**
 * Cette classe permet de gérer la forme
 *
 * @author Jérémy Marceau
 */
abstract public class Forme implements Comparable<Forme> {

    /**
     * Valeur minimale d'une dimension de la forme
     */
    public static final int MIN_VAL = 1;
    /**
     * Valeur maximale d'une dimension de la forme
     */
    public static final int MAX_VAL = 30;
    /**
     * Couleur par défaut de la forme
     */
    public static final Couleur COULEUR_DEFAUT = Couleur.ROUGE;

    /**
     * Nom de la forme
     */
    private String nom;
    /**
     * Couleur de la forme
     */
    private Couleur couleur;

    /**
     * Constructeur de la classe Forme
     *
     * @param nom : le nom de la forme
     */
    public Forme(String nom) {
        this.nom = nom;

        setCouleur(COULEUR_DEFAUT);
    }

    /**
     * Cette méthode permet de calculer le périmètre de la forme
     *
     * @return le périmètre d'une forme
     */
    abstract public int calculerPerimetre();

    /**
     * Cette méthode permet de calculer la surface de la forme
     *
     * @return la surface de la forme
     */
    abstract public int calculerSurface();

    /**
     * Cette méthode permet de comparer la forme courante avec une autre forme
     *
     * @param obj : Forme
     * @return : le résultat de la comparaison
     */
    @Override
    public int compareTo(Forme obj) {
        return (this.nom + this.couleur.getNom()).compareToIgnoreCase(obj.getNom() + obj.getCouleur().getNom());
    }

    /**
     * Cette méthode permet de vérifier l’égalité entre la forme courante et une autre forme
     *
     * @param obj : Forme
     * @return le résultat de la vérification de l'égalité entre la forme courante et une autre forme
     */
    @Override
    public boolean equals(Object obj) {
        return (obj instanceof Forme) && ((Forme) obj).calculerSurface() == calculerSurface() && ((Forme) obj).getCouleur().equals(this.couleur) && ((Forme) obj).getNom().equals(this.nom);
    }

    /**
     * Cette méthode permet d'obtenir la couleur de la forme
     *
     * @return la couleur de la forme
     */
    public Couleur getCouleur() {
        return this.couleur;
    }

    /**
     * Cette méthode permet d'obtenir le nom de la forme
     *
     * @return le nom de la forme
     */
    public String getNom() {
        return this.nom;
    }

    /**
     * Cette méthode permet d'assigner une couleur à la forme
     *
     * @param couleur : la couleur de la forme
     */
    public void setCouleur(Couleur couleur) {
        if (couleur != null) {
            this.couleur = couleur;
        }
    }

    /**
     * Cette classe permet de personnaliser les informations de la forme
     *
     * @return les informations personnalisées de la forme
     */
    abstract public String toString();

    public String toStringCourt() {
        return (this.nom + " " + this.couleur);
    }

}