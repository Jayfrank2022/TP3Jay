package formes;

import exceptions.FormeException;

import java.util.ArrayList;

/**
 * Cette interface est utilisée pour la manipulation de vecteur de formes
 *
 * @author Jérémy Marceau
 */
public interface ManipulerVecteur {
    /**
     * Cette méthode permet d'obtenir le vecteur de formes
     *
     * @return le vecteur de formes
     */
    ArrayList<Forme> getVecteur();

    /**
     * Cette méthode permet de mélanger le vecteur de formes
     */
    void melanger();

    /**
     * Cette méthode sert à remplir le vecteur de formes
     *
     * @param nbrFormes
     * @throws FormeException
     */
    void remplir(int nbrFormes) throws FormeException;

    /**
     * Cette méthode permet de trier le vecteur de formes
     */
    void trier();
}