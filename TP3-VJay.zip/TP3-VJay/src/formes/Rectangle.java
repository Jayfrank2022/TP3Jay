package formes;

import exceptions.FormeException;

/**
 * Cette classe permet de gérer le rectangle
 *
 * @author Jérémy Marceau
 */
public class Rectangle extends Forme {
    /**
     * hauteur du rectangle
     */
    private int hauteur;
    /**
     * largeur du rectangle
     */
    private int largeur;

    /**
     * Constructeur de la classe Rectangle
     *
     * @param hauteur : la hauteur du rectangle
     * @param largeur : la largeur du rectangle
     * @throws FormeException : exception personnalisée Forme
     */
    public Rectangle(int hauteur, int largeur) throws FormeException {
        super("Rectangle");

        if (validerHauteur(hauteur) && validerLargeur(largeur)) {
            setHauteur(hauteur);
            setLargeur(largeur);
        } else {
            throw new FormeException("Paramètre invalide passé au constructeur de la classe Rectangle");
        }
    }

    /**
     * Cette méthode permet de calculer le perimetre du rectangle
     *
     * @return le perimetre du rectangle
     */
    @Override
    public int calculerPerimetre() {
        return ((2 * this.hauteur) + (2 * this.largeur));
    }

    /**
     * Cette méthode permet de calculer la surface du rectangle
     *
     * @return la surface du rectangle
     */
    @Override
    public int calculerSurface() {
        return (this.hauteur * this.largeur);
    }

    /**
     * Cette méthode permet d'obtenir la hauteur du rectangle
     *
     * @return le hauteur du rectangle
     */
    public int getHauteur() {
        return this.hauteur;
    }

    /**
     * Cette méthode permet d'obtenir la largeur du rectangle
     *
     * @return le largeur du rectangle
     */
    public int getLargeur() {
        return this.largeur;
    }

    /**
     * Cette méthode permet d'assigner une hauteur au rectangle
     *
     * @param hauteur : hauteur du rectangle
     */
    public void setHauteur(int hauteur) {
        if (validerHauteur(hauteur)) {
            this.hauteur = hauteur;
        }
    }

    /**
     * Cette méthode permet d'assigner une largeur au rectangle
     *
     * @param largeur : largeur du rectangle
     */
    public void setLargeur(int largeur) {
        if (validerLargeur(largeur)) {
            this.largeur = largeur;
        }
    }

    /**
     * Cette méthode permet de personnaliser les informations du rectangle
     *
     * @return les informations personnalisées du rectangle
     */
    @Override
    public String toString() {
        return (this.toStringCourt() + " " + this.hauteur + ", " + this.largeur);
    }

    /**
     * Cette méthode permet de valider une hauteur de rectangle
     *
     * @param hauteur : hauteur de rectangle
     * @return le résultat de la validation de hauteur de rectangle
     */
    private static boolean validerHauteur(int hauteur) {
        return hauteur >= MIN_VAL && hauteur <= MAX_VAL;
    }

    /**
     * Cette méthode permet de valider une largeur de rectangle
     *
     * @param largeur : largeur de rectangle
     * @return le résultat de la validation de largeur de rectangle
     */
    private static boolean validerLargeur(int largeur) {
        return largeur >= MIN_VAL && largeur <= MAX_VAL;
    }
}