package formes;

import exceptions.FormeException;

import java.util.Arrays;

/**
 * Cette classe permet de gérer le triangle
 *
 * @author Jérémy Marceau
 */
public class Triangle extends Forme {

    /**
     * Longueur du côté A du triangle
     */
    private int coteA;
    /**
     * Longueur du côté B du triangle
     */
    private int coteB;
    /**
     * Longueur du côté C du triangle
     */
    private int coteC;

    /**
     * Constructeur de la classe Triangle
     *
     * @param coteA : longueur du côté A du triangle
     * @param coteB : longueur du côté B du triangle
     * @param coteC : longueur du côté C du triangle
     * @throws FormeException : exception personnalisée Forme
     */
    public Triangle(int coteA, int coteB, int coteC) throws FormeException {
        super("Triangle");

        if (validerCote(coteA) && validerCote(coteB) && validerCote(coteC)) {
            this.coteA = coteA;
            this.coteB = coteB;
            this.coteC = coteC;

            int[] cotesTries = getCotesTries();

            if (!estTriangle(cotesTries[0], cotesTries[1], cotesTries[2])) {
                throw new FormeException("Ce n'est pas un triangle");
            }
        } else {
            throw new FormeException("Paramètre invalide passé au constructeur de la classe Triangle");
        }
    }

    /**
     * Cette méthode permet de calculer le périmètre du triangle
     *
     * @return le périmètre du triangle
     */
    @Override
    public int calculerPerimetre() {
        return this.coteA + this.coteB + this.coteC;
    }

    /**
     * Cette méthode permet de calculer la surface du triangle
     *
     * @return la surface du triangle
     */
    @Override
    public int calculerSurface() {
        double dp = (double) calculerPerimetre() / 2;

        return (int) Math.sqrt(dp * (dp - this.coteA) * (dp - this.coteB) * (dp - this.coteC));

    }

    /**
     * Cette méthode permet de valider si le triangle est de type Rectangle
     *
     * @return le résultat de la validation si le triangle est de type Rectangle
     */
    private boolean estRectangle() {
        int[] cotesTries = getCotesTries();

        double hypothenuse = Math.sqrt(Math.pow(cotesTries[0], 2) + Math.pow(cotesTries[1], 2));

        return hypothenuse == cotesTries[2];
    }

    /**
     * Cette méthode permet de valider si nous sommes en présence d'un vrai triangle
     *
     * @param petitCote : Longueur de côté la plus petite d'un triangle
     * @param moyenCote : Longueur de côté autre que la plus petite et la plus grande d'un triangle
     * @param grandCote : Longueur de côté la plus grande d'un triangle
     * @return le résultat de la validation de présence d'un vrai triangle
     */
    private static boolean estTriangle(int petitCote, int moyenCote, int grandCote) {
        return grandCote < (petitCote + moyenCote);
    }

    /**
     * Cette méthode permet d'obtenir le côté A du triangle
     *
     * @return le côté A du triangle
     */
    public int getCoteA() {
        return this.coteA;
    }

    /**
     * Cette méthode permet d'obtenir le côté B du triangle
     *
     * @return le côté B du triangle
     */
    public int getCoteB() {
        return this.coteB;
    }

    /**
     * Cette méthode permet d'obtenir le côté C du triangle
     *
     * @return le côté C du triangle
     */
    public int getCoteC() {
        return this.coteC;
    }

    /**
     * Cette méthode permet de trier en ordre croissant les côtés du triangle
     *
     * @return les côtés du triangle triés en ordre croissant
     */
    private int[] getCotesTries() {
        int[] cotes = {this.coteA, this.coteB, this.coteC};


        Arrays.sort(cotes);

        return cotes;
    }

    /**
     * Cette méthode permet d'obtenir le nombre de côtés égaux du triangle
     *
     * @return le nombre de côtés égaux du triangle
     */
    private int getNbrCoteEgaux() {
        int nbCotesEgaux = 0;

        if (this.coteA == this.coteB) {
            nbCotesEgaux = 2;

            if (this.coteA == this.coteC) {
                nbCotesEgaux++;
            }
        } else if (this.coteA == this.coteC || this.coteB == this.coteC) {
            nbCotesEgaux = 2;
        }

        return nbCotesEgaux;
    }

    /**
     * Cette méthode permet d'obtenir le type du triangle
     *
     * @return le type du triangle
     */
    public TypeTriangle getType() {
        TypeTriangle typeTriangle;

        if (estRectangle()) {
            typeTriangle = TypeTriangle.RECTANGLE;
        } else {
            if (getNbrCoteEgaux() == 2) {
                typeTriangle = TypeTriangle.ISOCELE;
            } else if (getNbrCoteEgaux() == 3) {
                typeTriangle = TypeTriangle.EQUILATERAL;
            } else {
                typeTriangle = TypeTriangle.SCALENE;
            }
        }

        return typeTriangle;
    }

    /**
     * Cette méthode permet de personnaliser les informations du triangle
     *
     * @return les informations personnalisées du triangle
     */
    @Override
    public String toString() {
        return (this.toStringCourt() + " " + this.coteA + ", " + this.coteB + ", " + this.coteC);
    }


    /**
     * Cette méthode permet de valider un côté du triangle
     *
     * @param cote : côté de triangle
     * @return le résultat de la validation d'un côté du triangle
     */
    private static boolean validerCote(int cote) {
        return (cote >= MIN_VAL && cote <= MAX_VAL);
    }
}