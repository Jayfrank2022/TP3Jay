package formes;

/**
 * Cet Enum permet de gérer les types de triangle
 *
 * @author Jérémy Marceau
 */
public enum TypeTriangle {
    /**
     * Liste des éléments de l'Enum TypeCouleur
     */
    ISOCELE("isocèle"), EQUILATERAL("équilatéral"), RECTANGLE("rectangle"), SCALENE("scalène");

    /**
     * Type de triangle
     */
    private String type;

    /**
     * Constructeur de l'Enum TypeTriangle
     *
     * @param type : le nom du type de triangle
     */
    TypeTriangle(String type) {
        setType(type);
    }

    /**
     * Cette méthode permet d'obtenir le type de triangle
     *
     * @return le type du triangle
     */
    public String getType() {
        return this.type;
    }

    /**
     * Cette méthode d'assigner un type de triangle
     */
    private void setType(String type) {
        this.type = type;
    }

    /**
     * Cette méthode permet de personnaliser les informations du type de triangle
     *
     * @return les informations personnalisées du type de triangle
     */
    @Override
    public String toString() {
        return this.type;
    }

}