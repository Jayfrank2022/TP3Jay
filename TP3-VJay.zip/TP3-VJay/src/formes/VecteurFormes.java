package formes;


import exceptions.FormeException;

import java.util.ArrayList;
import java.util.Random;

/**
 * Cette classe permet de gérer le vecteur de formes
 *
 * @author Jérémy Marceau
 */
public class VecteurFormes implements ManipulerVecteur {

    /**
     * Vecteur de formes
     */
    private ArrayList<Forme> vecteur;

    /**
     * Constructeur de la classe VecteurFormes
     */
    public VecteurFormes() {

    }

    /**
     * Cette méthode permet d'obtenir le vecteur de formes
     *
     * @return le vecteur de formes
     */
    @Override
    public ArrayList<Forme> getVecteur() {
        return this.vecteur;
    }

    /**
     * Cette méthode permet de mélanger le vecteur de formes
     */
    @Override
    public void melanger() {
        Random rdm = new Random();

        for (int x = 0; x < this.vecteur.size(); x++) {
            permuter(x, rdm.nextInt(this.vecteur.size() - 1));
        }
    }


    /**
     * Cette méthode sert à permuter le vecteur de formes
     *
     * @param indiceA
     * @param indiceB
     */
    private void permuter(int indiceA, int indiceB) {
        ArrayList<Forme> vecteurTemp = new ArrayList<>();

        vecteurTemp.add(this.vecteur.get(indiceA));
        vecteurTemp.add(this.vecteur.get(indiceB));

        this.vecteur.set(indiceA, vecteurTemp.get(1));
        this.vecteur.set(indiceB, vecteurTemp.get(0));

    }

    /**
     * Cette méthode sert à remplir le vecteur de formes
     *
     * @param nbrFormes
     * @throws FormeException
     */
    @Override
    public void remplir(int nbrFormes) throws FormeException {
        int compteur = 0;

        this.vecteur = new ArrayList<>();

        String[] formes = {"cercle", "rectangle", "triangle"};

        if (validerNbrFormes(nbrFormes)) {
            while (compteur < nbrFormes) {
                for (Couleur couleur : Couleur.values()) {
                    for (int x = 0; x < formes.length && compteur < nbrFormes; x++) {
                        Forme frm;

                        if (formes[x].equals("cercle")) {
                            frm = new Cercle(Forme.MAX_VAL);
                        } else if (formes[x].equals("rectangle")) {
                            frm = new Rectangle(Forme.MAX_VAL, Forme.MAX_VAL);
                        } else {
                            frm = new Triangle(5, 3, 4);
                        }

                        frm.setCouleur(couleur);
                        this.vecteur.add(frm);
                        compteur++;
                    }

                    if (compteur >= nbrFormes) {
                        break;
                    }
                }
            }
        } else {
            throw new ArrayIndexOutOfBoundsException();
        }
    }

    /**
     * Cette méthode permet de personnaliser les informations du vecteur de formes
     *
     * @return les informations personnalisées du vecteur de formes
     */
    @Override
    public String toString() {
        String chaine = "";

        for (int x = 0; x < this.vecteur.size(); x++) {
            chaine = chaine + this.vecteur.get(x).toStringCourt() + "\n";
        }

        return chaine;
    }

    /**
     * Cette méthode permet de trier le vecteur de formes
     */
    @Override
    public void trier() {
        Forme valTemp;
        int indiceTemp;

        for (int courant = 0; courant < this.vecteur.size() - 1; courant++) {
            indiceTemp = courant;

            for (int position = courant + 1; position < this.vecteur.size(); position++) {
                if (this.vecteur.get(position).compareTo(this.vecteur.get(indiceTemp)) < 0) {
                    // Valeur de l'indice du vecteur
                    indiceTemp = position;
                }
            }

            // échange
            if (indiceTemp != courant) {
                valTemp = this.vecteur.get(indiceTemp);
                this.vecteur.set(indiceTemp, this.vecteur.get(courant));
                this.vecteur.set(courant, valTemp);
            }
        }
    }

    /**
     * cette méthode permet de valider le nombre de formes contenues dans le vecteur
     *
     * @param nbrFormes
     * @return le résultat de la validation
     */
    private static boolean validerNbrFormes(int nbrFormes) {
        return nbrFormes >= 0;
    }
}

