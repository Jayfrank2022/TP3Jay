package jeu;

import exceptions.FormeException;
import formes.Forme;
import formes.VecteurFormes;

import java.awt.*;
import java.util.ArrayList;

import static utilitaires.Utilitaires.alea;

/**
 * Cette classe permet de gérer le jeu de mémoire *
 *
 * @author Jérémy Marceau
 */
public class JeuMemoire implements Memorisable {

    /**
     * Longueur d'une ligne
     */
    public static final int LIGNE = 6;

    /**
     * Longueur d'une colonne
     */
    public static final int COLONNE = 6;

    /**
     * Nombre d'éléments dans la grille
     */
    public static final int NBR_ELEMENTS_GRILLE = LIGNE * COLONNE;

    /**
     * Longueur de la chaîne
     */
    private static final int LONGUEUR_CHAINE = 17;

    /**
     * Liste de formes
     */
    private VecteurFormes vecteurFormes;

    /**
     * Tableau double contenant des formes
     */
    private Forme[][] grilleDeJeu;

    /**
     * Liste de points
     */
    private ArrayList<Point> vecteurPoints;

    /**
     * Le niveau initial
     */
    private int niveau = 1;

    /**
     * Constructeur de la classe JeuMemoire
     *
     * @throws FormeException
     */
    public JeuMemoire() {
        try {
            preparerVecteurFormes();
            preparerGrilleDeJeu();
        } catch (Exception e) {
            System.out.println("Une erreur est survenue à l'instanciation de la classe JeuMemoire");
        }
    }

    /**
     * Cette méthode permet d'ajouter des espaces à une chaîne de caractères
     *
     * @param longueurChaine
     * @param chaine
     * @return une chaîne de caractères
     */
    private String ajouterEspaces(int longueurChaine, String chaine) {
        for (int x = chaine.length(); x < longueurChaine; x++) {
            chaine = chaine + " ";
        }

        return chaine;
    }


    /**
     * Cette méthode permet de choisir une forme aléatoirement
     *
     * @return un Point
     */
    private Point choisirForme() {
        return new Point(alea(0, LIGNE - 1), alea(0, COLONNE - 1));
    }

    /**
     * Permet d'obtenir la grille de jeu
     *
     * @return la grille de jeu
     */
    private Forme[][] getGrille() {
        return this.grilleDeJeu;
    }

    /**
     * Cette méthode permet d'obtenir le niveau
     *
     * @return le niveau
     */
    @Override
    public int getNiveau() {
        return this.niveau;
    }

    /**
     * Cette méthode permet d'obtenir le nom personnalisé d'une forme de la grille
     *
     * @param x
     * @param y
     * @return le nom personnalisé de la forme
     */
    @Override
    public String getNomForme(int x, int y) {
        return getGrille()[x][y].getNom() + getGrille()[x][y].getCouleur();
    }


    /**
     * Cette méthode permet d'obtenir le vecteur de formes
     *
     * @return le vecteur de formes
     */
    public VecteurFormes getVecteur() {
        return this.vecteurFormes;
    }


    /**
     * Cette méthode permet de vérifier  si la coordonnée x, y de la forme à deviner est celle reçue en paramètre.
     *
     * @param x
     * @param y
     * @return le résultat de la vérification
     */
    @Override
    public boolean jouerHumain(int x, int y) {
        boolean bonneCoord = false;

        if (!this.vecteurPoints.isEmpty()) {
            Point p = this.vecteurPoints.get(0);
            this.vecteurPoints.remove(0);

            bonneCoord = p.x == x && p.y == y;
        }

        return bonneCoord;
    }

    /**
     * Cette méthode permet de créer une liste de points
     *
     * @return une liste de points
     */
    @Override
    public ArrayList<Point> jouerOrdi() {
        this.vecteurPoints = new ArrayList<>();

        for (int x = 0; x < this.niveau + 2; x++) {
            Point p;
            do {
                p = choisirForme();
            } while (this.vecteurPoints.contains(p));

            this.vecteurPoints.add(p);
        }

        return this.vecteurPoints;
    }

    /**
     * Cette méthode permet de préparer la grille de jeu
     */
    private void preparerGrilleDeJeu() {
        this.grilleDeJeu = new Forme[LIGNE][COLONNE];
        for (int x = 0; x < getVecteur().getVecteur().size(); x++) {
            this.grilleDeJeu[x / LIGNE][x % LIGNE] = getVecteur().getVecteur().get(x);
        }
    }


    /**
     * Cette méthode permet de préparer le vecteur de formes
     *
     * @throws FormeException
     */
    private void preparerVecteurFormes() throws FormeException {
        this.vecteurFormes = new VecteurFormes();
        this.vecteurFormes.remplir(NBR_ELEMENTS_GRILLE);
        this.vecteurFormes.melanger();
    }

    /**
     * Cette méthode permet d'augmenter de un le niveau
     */
    @Override
    public void setNiveauPlusUn() {
        if (getNiveau() < NIVEAU_MAX) {
            this.niveau++;
        }
    }

    /**
     * Cette méthode permet de personnaliser les informations du jeu de mémoire
     *
     * @return les informations personnalisées du jeu de mémoire
     */
    @Override
    public String toString() {
        String chaine = "";
        for (int x = 0; x < getGrille().length; x++) {
            for (int y = 0; y < getGrille()[x].length; y++) {
                chaine = chaine + ajouterEspaces(LONGUEUR_CHAINE, getGrille()[x][y].toStringCourt()) + "| ";
            }

            chaine = chaine + "\n";
        }

        return chaine;
    }
}