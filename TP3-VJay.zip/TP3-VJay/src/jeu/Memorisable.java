package jeu;

import java.awt.*;
import java.util.ArrayList;

/**
 * Cette interface est utilisée pour la gestion du jeu de mémoire
 *
 * @author Jérémy Marceau
 */
public interface Memorisable {

    /**
     * Niveau maximum
     */
    static final int NIVEAU_MAX = 6;

    /**
     * Cette méthode permet d'obtenir le niveau
     *
     * @return le niveau
     */
    int getNiveau();

    /**
     * Cette méthode permet d'obtenir le nom personnalisé d'une forme de la grille
     *
     * @param x
     * @param y
     * @return le nom personnalisé de la forme
     */
    String getNomForme(int x, int y);

    /**
     * Cette méthode permet de vérifier  si la coordonnée x, y de la forme à deviner est celle reçue en paramètre.
     *
     * @param x
     * @param y
     * @return le résultat de la vérification
     */
    boolean jouerHumain(int x, int y);

    /**
     * Cette méthode permet de créer une liste de points
     *
     * @return une liste de points
     */
    ArrayList<Point> jouerOrdi();

    /**
     * Cette méthode permet d'augmenter de un le niveau
     */
    void setNiveauPlusUn();
}