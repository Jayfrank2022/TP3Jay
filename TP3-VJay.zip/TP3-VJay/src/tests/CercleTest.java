package tests;

import exceptions.FormeException;
import formes.Cercle;
import formes.Couleur;
import formes.Forme;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Cette classe permet de tester la classe Cercle
 *
 * @author Jérémy Marceau
 */
public class CercleTest {
    private Cercle cercle1, cercle2, cercle3, cercle4;

    /**
     * Cette méthode permet de configurer les tests de classe Cercle
     *
     * @throws Exception : : exception générique
     */
    @Before
    public void setUp() throws Exception {
        cercle1 = new Cercle(1);
        cercle2 = new Cercle(2);
        cercle3 = new Cercle(30);
        cercle4 = new Cercle(2);
    }

    /**
     * Cette méthode permet de tester les scénarios invalides de la classe Cercle
     */
    @Test
    public void testInvalides() {
        try {
            new Cercle(0);
            fail("Cercle invalide");

        } catch (FormeException e) {
        }

        try {
            new Cercle(31);
            fail("Cercle invalide");

        } catch (FormeException e) {
        }
    }

    /**
     * Cette méthode permet de tester la comparaison du cercle avec un autre cercle
     */
    @Test
    public void compareTo() {
        assertEquals(cercle1.compareTo(cercle2), 0);
        assertEquals(cercle1.compareTo(cercle3), 0);
        assertEquals(cercle1.compareTo(cercle4), 0);
        assertEquals(cercle2.compareTo(cercle3), 0);
        assertEquals(cercle2.compareTo(cercle4), 0);
        assertEquals(cercle3.compareTo(cercle4), 0);

        cercle1.setCouleur(Couleur.ORANGE);
        assertEquals(cercle1.compareTo(cercle2), -3);

        cercle1.setCouleur(Couleur.BLEU);
        assertEquals(cercle1.compareTo(cercle2), -16);

        cercle1.setCouleur(Couleur.JAUNE);
        assertEquals(cercle1.compareTo(cercle2), -8);

        cercle1.setCouleur(Couleur.NOIR);
        assertEquals(cercle1.compareTo(cercle2), -4);

        cercle1.setCouleur(Couleur.VERT);
        assertEquals(cercle1.compareTo(cercle2), 4);
    }

    /**
     * Cette méthode permet de tester l'égalité du cercle courant avec un autre cercle
     */
    @Test
    public void equals() {
        assertFalse(cercle1.equals(cercle2));
        assertFalse(cercle1.equals(cercle3));
        assertFalse(cercle1.equals(cercle4));
        assertFalse(cercle2.equals(cercle3));
        assertTrue(cercle2.equals(cercle4));
        assertFalse(cercle3.equals(cercle4));

    }

    /**
     * Cette méthode permet de tester l'obtention de la couleur d'un cercle
     */
    @Test
    public void getCouleur() {
        assertEquals(cercle1.getCouleur(), Cercle.COULEUR_DEFAUT);
        assertEquals(cercle2.getCouleur(), Cercle.COULEUR_DEFAUT);
        assertEquals(cercle3.getCouleur(), Cercle.COULEUR_DEFAUT);
        assertEquals(cercle4.getCouleur(), Cercle.COULEUR_DEFAUT);
    }

    /**
     * Cette méthode permet de tester l'obtention du nom d'un cercle
     */
    @Test
    public void getNom() {
        assertEquals(cercle1.getNom(), "Cercle");
        assertEquals(cercle2.getNom(), "Cercle");
        assertEquals(cercle3.getNom(), "Cercle");
        assertEquals(cercle4.getNom(), "Cercle");
    }

    /**
     * Cette méthode permet de tester l'assignation de couleurs valides d'un cercle
     */
    @Test
    public void setCouleur() {
        cercle1.setCouleur(Couleur.ROUGE);
        assertEquals(cercle1.getCouleur(), Couleur.ROUGE);

        cercle2.setCouleur(Couleur.VERT);
        assertEquals(cercle2.getCouleur(), Couleur.VERT);

        cercle3.setCouleur(Couleur.BLEU);
        assertEquals(cercle3.getCouleur(), Couleur.BLEU);

        cercle4.setCouleur(Couleur.JAUNE);
        assertEquals(cercle4.getCouleur(), Couleur.JAUNE);

        cercle1.setCouleur(Couleur.NOIR);
        assertEquals(cercle1.getCouleur(), Couleur.NOIR);

        cercle2.setCouleur(Couleur.ORANGE);
        assertEquals(cercle2.getCouleur(), Couleur.ORANGE);

        cercle1.setCouleur(null);
        assertEquals(cercle1.getCouleur(), Couleur.NOIR);

        cercle2.setCouleur(null);
        assertEquals(cercle2.getCouleur(), Couleur.ORANGE);

        cercle3.setCouleur(null);
        assertEquals(cercle3.getCouleur(), Couleur.BLEU);

        cercle4.setCouleur(null);
        assertEquals(cercle4.getCouleur(), Couleur.JAUNE);
    }

    /**
     * Cette méthode permet de tester le calcul de périmètre d'un cercle
     */
    @Test
    public void calculerPerimetre() {
        assertEquals(cercle1.calculerPerimetre(), 6);
        assertEquals(cercle2.calculerPerimetre(), 12);
        assertEquals(cercle3.calculerPerimetre(), 188);
        assertEquals(cercle4.calculerPerimetre(), 12);
    }

    /**
     * Cette méthode permet de tester le calcul de surface d'un cercle
     */
    @Test
    public void calculerSurface() {
        assertEquals(cercle1.calculerSurface(), 3);
        assertEquals(cercle2.calculerSurface(), 12);
        assertEquals(cercle3.calculerSurface(), 2827);
        assertEquals(cercle4.calculerSurface(), 12);
    }

    /**
     * Cette méthode permet de tester l'obtention du rayon d'un cercle
     */
    @Test
    public void getRayon() {
        assertEquals(cercle1.getRayon(), 1);
        assertEquals(cercle2.getRayon(), 2);
        assertEquals(cercle3.getRayon(), 30);
        assertEquals(cercle4.getRayon(), 2);
    }

    /**
     * Cette méthode permet de tester l'assignation de rayon valide d'un cercle
     */
    @Test
    public void setRayon() {
        cercle1.setRayon(0);
        assertEquals(cercle1.getRayon(), 1);

        for (int x = Forme.MIN_VAL; x <= Forme.MAX_VAL; x++) {
            cercle1.setRayon(x);
            assertEquals(cercle1.getRayon(), x);
        }

        cercle2.setRayon(31);
        assertEquals(cercle2.getRayon(), 2);

        cercle3.setRayon(0);
        assertEquals(cercle3.getRayon(), 30);

        cercle4.setRayon(31);
        assertEquals(cercle4.getRayon(), 2);
    }

    /**
     * Cette méthode permet de tester la personnalisation des informations d'un cercle
     */
    @Test
    public void testToString() {
        assertEquals(cercle1.toString(), "Cercle rouge 1");
        assertEquals(cercle2.toString(), "Cercle rouge 2");
        assertEquals(cercle3.toString(), "Cercle rouge 30");
        assertEquals(cercle4.toString(), "Cercle rouge 2");
    }
}