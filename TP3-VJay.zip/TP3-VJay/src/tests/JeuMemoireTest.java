package tests;

import jeu.JeuMemoire;
import org.junit.Before;
import org.junit.Test;

import java.awt.*;
import java.util.ArrayList;

import static org.junit.Assert.*;

/**
 * Cette classe permet de tester la classe JeuMemoire
 *
 * @author Jérémy Marceau
 */
public class JeuMemoireTest {

    private JeuMemoire jeuMemoire1;

    /**
     * Cette méthode permet de configurer les tests de classe JeuMemoire
     *
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception {
        jeuMemoire1 = new JeuMemoire();
    }

    /**
     * Cette méthode permet de tester les scénarios invalides de la classe JeuMemoire
     */
    @Test
    public void testInvalides() {
        try {
            jeuMemoire1.jouerHumain(0, 0);
            fail("Test invalide passé");

        } catch (Exception e) {
            System.out.println(e.toString());
        }

        try {
            jeuMemoire1.getNomForme(6, 6);
            fail("Test invalide passé");

        } catch (Exception e) {
            System.out.println(e.toString());
        }

        try {
            jeuMemoire1.getNomForme(-1, -1);
            fail("Test invalide passé");

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    /**
     * Cette méthode permet de tester l'obtention du niveau
     */
    @Test
    public void getNiveau() {
        assertEquals(jeuMemoire1.getNiveau(), 1);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 2);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 3);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 4);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 5);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 6);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 6);
    }

    /**
     * Cette méthode permet de tester l'obtention du nom personnalisé d'une forme de la grille
     */
    @Test
    public void getNomForme() {
        String[] listeNoms = {"Cerclerouge", "Cerclevert", "Cerclebleu", "Cerclejaune", "Cerclenoir", "Cercleorange", "Rectanglerouge", "Rectanglevert", "Rectanglebleu", "Rectanglejaune", "Rectanglenoir", "Rectangleorange", "Trianglerouge", "Trianglevert", "Trianglebleu", "Trianglejaune", "Trianglenoir", "Triangleorange"};
        String nomForme;

        for (int x = 0; x < JeuMemoire.LIGNE; x++) {
            for (int y = 0; y < JeuMemoire.COLONNE; y++) {
                nomForme = jeuMemoire1.getNomForme(x, y);

                boolean contientNom = false;
                for (int z = 0; z < listeNoms.length; z++) {
                    if (nomForme.equals(listeNoms[z])) {
                        contientNom = true;
                        break;
                    }
                }

                assertTrue(contientNom);
            }
        }
    }

    /**
     * Cette méthode permet de tester l'obtention du vecteur de formes
     */
    @Test
    public void getVecteur() {
        jeuMemoire1.getVecteur().trier();

        String toStringAComparer = "Cercle bleu\nCercle bleu\nCercle jaune\nCercle jaune\nCercle noir\nCercle noir\nCercle orange\nCercle orange\nCercle rouge\nCercle rouge\nCercle vert\nCercle vert\nRectangle bleu\nRectangle bleu\nRectangle jaune\nRectangle jaune\nRectangle noir\nRectangle noir\nRectangle orange\nRectangle orange\nRectangle rouge\nRectangle rouge\nRectangle vert\nRectangle vert\nTriangle bleu\nTriangle bleu\nTriangle jaune\nTriangle jaune\nTriangle noir\nTriangle noir\nTriangle orange\nTriangle orange\nTriangle rouge\nTriangle rouge\nTriangle vert\nTriangle vert\n";
        assertEquals(jeuMemoire1.getVecteur().toString(), toStringAComparer);
    }

    /**
     * Cette méthode permet de tester la vérification si la coordonnée x, y de la forme à deviner est celle reçue en paramètre.
     */
    @Test
    public void jouerHumain() {
        ArrayList<Point> arrPoints;

        arrPoints = (ArrayList<Point>) jeuMemoire1.jouerOrdi().clone();

        for (int x = 0; x < arrPoints.size(); x++) {
            assertTrue(jeuMemoire1.jouerHumain(arrPoints.get(x).x, arrPoints.get(x).y));
        }

        jeuMemoire1.setNiveauPlusUn();
        arrPoints = (ArrayList<Point>) jeuMemoire1.jouerOrdi().clone();

        for (int x = 0; x < arrPoints.size(); x++) {
            assertTrue(jeuMemoire1.jouerHumain(arrPoints.get(x).x, arrPoints.get(x).y));
        }

        jeuMemoire1.setNiveauPlusUn();
        jeuMemoire1.setNiveauPlusUn();
        jeuMemoire1.setNiveauPlusUn();
        jeuMemoire1.setNiveauPlusUn();
        jeuMemoire1.setNiveauPlusUn();
        arrPoints = (ArrayList<Point>) jeuMemoire1.jouerOrdi().clone();

        for (int x = 0; x < arrPoints.size(); x++) {
            assertTrue(jeuMemoire1.jouerHumain(arrPoints.get(x).x, arrPoints.get(x).y));
        }
    }

    /**
     * Cette méthode permet de tester la création d'un liste de points
     */
    @Test
    public void jouerOrdi() {
        ArrayList<Point> arrPoints;

        arrPoints = jeuMemoire1.jouerOrdi();
        assertEquals(arrPoints.size(), 3);

        jeuMemoire1.setNiveauPlusUn();
        arrPoints = jeuMemoire1.jouerOrdi();
        assertEquals(arrPoints.size(), 4);

        jeuMemoire1.setNiveauPlusUn();
        arrPoints = jeuMemoire1.jouerOrdi();
        assertEquals(arrPoints.size(), 5);

        jeuMemoire1.setNiveauPlusUn();
        arrPoints = jeuMemoire1.jouerOrdi();
        assertEquals(arrPoints.size(), 6);

        jeuMemoire1.setNiveauPlusUn();
        arrPoints = jeuMemoire1.jouerOrdi();
        assertEquals(arrPoints.size(), 7);

        jeuMemoire1.setNiveauPlusUn();
        arrPoints = jeuMemoire1.jouerOrdi();
        assertEquals(arrPoints.size(), 8);

        jeuMemoire1.setNiveauPlusUn();
        arrPoints = jeuMemoire1.jouerOrdi();
        assertEquals(arrPoints.size(), 8);

    }

    /**
     * Cette méthode permet de tester l'augmentation de un le niveau
     */
    @Test
    public void setNiveauPlusUn() {
        assertEquals(jeuMemoire1.getNiveau(), 1);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 2);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 3);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 4);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 5);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 6);
        jeuMemoire1.setNiveauPlusUn();
        assertEquals(jeuMemoire1.getNiveau(), 6);
    }

    /**
     * Cette méthode permet de tester la personnalisation des informations du jeu de mémoire
     */
    @Test
    public void testToString() {
        int cptCar = 0;

        for (int x = 0; x < JeuMemoire.LIGNE; x++) {
            for (int y = 0; y < JeuMemoire.COLONNE; y++) {
                cptCar = cptCar + 17;
                assertEquals(jeuMemoire1.toString().charAt(cptCar), '|');
                cptCar = cptCar + 2;
            }

            assertEquals(jeuMemoire1.toString().substring(cptCar, cptCar + 1), "\n");
            cptCar++;
        }

        System.out.println(jeuMemoire1.toString());
    }
}