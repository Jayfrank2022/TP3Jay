package tests;

import exceptions.FormeException;
import formes.Couleur;
import formes.Forme;
import formes.Rectangle;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Cette classe permet de tester la classe Rectangle
 *
 * @author Jérémy Marceau
 */
public class RectangleTest {
    private Rectangle rectangle1, rectangle2, rectangle3, rectangle4, rectangle5, rectangle6;

    /**
     * Cette méthode permet de configurer les tests de classe Rectangle
     *
     * @throws Exception : exception générique
     */
    @Before
    public void setUp() throws Exception {

        rectangle1 = new Rectangle(1, 1);
        rectangle2 = new Rectangle(2, 2);
        rectangle3 = new Rectangle(5, 10);
        rectangle4 = new Rectangle(10, 5);
        rectangle5 = new Rectangle(30, 11);
        rectangle6 = new Rectangle(12, 30);
    }

    /**
     * Cette méthode permet de tester les scénarios invalides de la classe Rectangle
     */
    @Test
    public void testInvalides() {
        try {
            new Rectangle(0, 0);
            fail("Rectangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Rectangle(0, 30);
            fail("Rectangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Rectangle(30, 0);
            fail("Rectangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Rectangle(31, 31);
            fail("Rectangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Rectangle(1, 31);
            fail("Rectangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Rectangle(31, 1);
            fail("Rectangle invalide");

        } catch (FormeException e) {
        }

    }

    /**
     * Cette méthode permet de tester le calcul du périmètre d'un rectangle
     */
    @Test
    public void calculerPerimetre() {
        assertEquals(rectangle1.calculerPerimetre(), 4);
        assertEquals(rectangle2.calculerPerimetre(), 8);
        assertEquals(rectangle3.calculerPerimetre(), 30);
        assertEquals(rectangle4.calculerPerimetre(), 30);
        assertEquals(rectangle5.calculerPerimetre(), 82);
        assertEquals(rectangle6.calculerPerimetre(), 84);
    }

    /**
     * Cette méthode permet de tester le calcul de la surface d'un rectangle
     */
    @Test
    public void calculerSurface() {
        assertEquals(rectangle1.calculerSurface(), 1);
        assertEquals(rectangle2.calculerSurface(), 4);
        assertEquals(rectangle3.calculerSurface(), 50);
        assertEquals(rectangle4.calculerSurface(), 50);
        assertEquals(rectangle5.calculerSurface(), 330);
        assertEquals(rectangle6.calculerSurface(), 360);
    }

    /**
     * Cette méthode permet de tester l'égalité du rectangle courant avec un autre rectangle
     */
    @Test
    public void equals() {
        assertFalse(rectangle1.equals(rectangle2));
        assertFalse(rectangle1.equals(rectangle3));
        assertFalse(rectangle1.equals(rectangle4));
        assertFalse(rectangle1.equals(rectangle5));
        assertFalse(rectangle1.equals(rectangle6));
        assertFalse(rectangle2.equals(rectangle3));
        assertFalse(rectangle2.equals(rectangle4));
        assertFalse(rectangle2.equals(rectangle5));
        assertFalse(rectangle2.equals(rectangle6));
        assertTrue(rectangle3.equals(rectangle4));
        assertFalse(rectangle3.equals(rectangle5));
        assertFalse(rectangle3.equals(rectangle6));
        assertFalse(rectangle4.equals(rectangle5));
        assertFalse(rectangle4.equals(rectangle6));
        assertFalse(rectangle5.equals(rectangle6));
    }

    /**
     * Cette méthode permet de tester la personnalisation des informations d'un rectangle
     */
    @Test
    public void testToString() {
        assertEquals(rectangle1.toString(), "Rectangle rouge 1, 1");
        assertEquals(rectangle2.toString(), "Rectangle rouge 2, 2");
        assertEquals(rectangle3.toString(), "Rectangle rouge 5, 10");
        assertEquals(rectangle4.toString(), "Rectangle rouge 10, 5");
        assertEquals(rectangle5.toString(), "Rectangle rouge 30, 11");
        assertEquals(rectangle6.toString(), "Rectangle rouge 12, 30");
    }

    /**
     * Cette méthode permet de tester la comparaison du rectangle avec un autre rectangle
     */
    @Test
    public void compareTo() {
        assertEquals(rectangle1.compareTo(rectangle2), 0);
        assertEquals(rectangle2.compareTo(rectangle3), 0);
        assertEquals(rectangle1.compareTo(rectangle3), 0);
    }

    /**
     * Cette méthode permet de tester l'obtention de la couleur d'un rectangle
     */
    @Test
    public void getCouleur() {
        assertEquals(rectangle1.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(rectangle2.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(rectangle3.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(rectangle4.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(rectangle5.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(rectangle6.getCouleur(), Rectangle.COULEUR_DEFAUT);
    }

    /**
     * Cette méthode permet de tester l'obtention de la hauteur d'un rectangle
     */
    @Test
    public void getHauteur() {
        assertEquals(rectangle1.getHauteur(), 1);
        assertEquals(rectangle2.getHauteur(), 2);
        assertEquals(rectangle3.getHauteur(), 5);
        assertEquals(rectangle4.getHauteur(), 10);
        assertEquals(rectangle5.getHauteur(), 30);
        assertEquals(rectangle6.getHauteur(), 12);
    }

    /**
     * Cette méthode permet de tester l'obtention de la largeur d'un rectangle
     */
    @Test
    public void getLargeur() {
        assertEquals(rectangle1.getLargeur(), 1);
        assertEquals(rectangle2.getLargeur(), 2);
        assertEquals(rectangle3.getLargeur(), 10);
        assertEquals(rectangle4.getLargeur(), 5);
        assertEquals(rectangle5.getLargeur(), 11);
        assertEquals(rectangle6.getLargeur(), 30);
    }

    /**
     * Cette méthode permet de tester l'obtention du nom d'un rectangle
     */
    @Test
    public void getNom() {
        assertEquals(rectangle1.getNom(), "Rectangle");
        assertEquals(rectangle2.getNom(), "Rectangle");
        assertEquals(rectangle3.getNom(), "Rectangle");
        assertEquals(rectangle4.getNom(), "Rectangle");
        assertEquals(rectangle5.getNom(), "Rectangle");
        assertEquals(rectangle6.getNom(), "Rectangle");
    }

    /**
     * Cette méthode permet de tester l'assignation des couleurs valides d'un rectangle
     */
    @Test
    public void setCouleur() {
        for (Couleur c : Couleur.values()) {
            rectangle3.setCouleur(c);
            assertEquals(rectangle3.getCouleur(), c);
        }

        rectangle4.setCouleur(null);
        assertEquals(rectangle4.getCouleur(), Rectangle.COULEUR_DEFAUT);
    }

    /**
     * Cette méthode permet de tester l'assignation des hauteurs valides d'un rectangle
     */
    @Test
    public void setHauteur() {
        for (int x = Forme.MIN_VAL; x <= Forme.MAX_VAL; x++) {
            rectangle1.setHauteur(x);
            assertEquals(rectangle1.getHauteur(), x);
        }
    }

    /**
     * Cette méthode permet de tester l'assignation des largeurs valides d'un rectangle
     */
    @Test
    public void setLargeur() {
        for (int x = Forme.MIN_VAL; x <= Forme.MAX_VAL; x++) {
            rectangle1.setLargeur(x);
            assertEquals(rectangle1.getLargeur(), x);
        }
    }
}