package tests;

import exceptions.FormeException;
import formes.Couleur;
import formes.Rectangle;
import formes.Triangle;
import formes.TypeTriangle;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Cette classe permet de tester la classe Triangle
 *
 * @author Jérémy Marceau
 */
public class TriangleTest {

    private Triangle triangle1, triangle2, triangle3, triangle4, triangle5, triangle6;

    /**
     * Cette méthode permet de configurer les tests de classe Triangle
     *
     * @throws Exception : exception générique
     */
    @Before
    public void setUp() throws Exception {
        triangle1 = new Triangle(1, 1, 1);
        triangle2 = new Triangle(2, 2, 3);
        triangle3 = new Triangle(5, 3, 4);
        triangle4 = new Triangle(7, 4, 5);
        triangle5 = new Triangle(3, 5, 4);
        triangle6 = new Triangle(15, 9, 8);
    }

    /**
     * Cette méthode permet de tester les scénarios invalides de la classe Triangle
     */
    @Test
    public void testInvalides() {
        try {
            new Triangle(0, 0, 0);
            fail("Triangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Triangle(1, 15, 30);
            fail("Triangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Triangle(30, 0, 0);
            fail("Triangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Triangle(31, 31, 31);
            fail("Triangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Triangle(1, 31, 31);
            fail("Triangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Triangle(31, 1, 1);
            fail("Triangle invalide");

        } catch (FormeException e) {
        }

        try {
            new Triangle(9, 2, 3);
            fail("Triangle invalide");

        } catch (FormeException e) {
        }

    }

    /**
     * Cette méthode permet de tester la comparaison d'un triangle avec un autre triangle
     */
    @Test
    public void compareTo() {
        assertEquals(triangle1.compareTo(triangle2), 0);
        assertEquals(triangle2.compareTo(triangle3), 0);
        assertEquals(triangle1.compareTo(triangle3), 0);
    }

    /**
     * Cette méthode permet de tester l'égalité d'un triangle avec un autre triangle
     */
    @Test
    public void equals() {
        assertFalse(triangle1.equals(triangle2));
        assertFalse(triangle1.equals(triangle3));
        assertFalse(triangle1.equals(triangle4));
        assertFalse(triangle1.equals(triangle5));
        assertFalse(triangle1.equals(triangle6));
        assertFalse(triangle2.equals(triangle4));
        assertFalse(triangle2.equals(triangle5));
        assertFalse(triangle2.equals(triangle6));
        assertFalse(triangle3.equals(triangle4));
        assertTrue(triangle3.equals(triangle5));
        assertFalse(triangle3.equals(triangle6));
        assertFalse(triangle4.equals(triangle5));
        assertFalse(triangle4.equals(triangle6));
        assertFalse(triangle5.equals(triangle6));
    }

    /**
     * Cette méthode permet de tester l'obtention de la couleur d'un triangle
     */
    @Test
    public void getCouleur() {
        assertEquals(triangle1.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(triangle2.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(triangle3.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(triangle4.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(triangle5.getCouleur(), Rectangle.COULEUR_DEFAUT);
        assertEquals(triangle6.getCouleur(), Rectangle.COULEUR_DEFAUT);
    }

    /**
     * Cette méthode permet de tester l'obtention du nom d'un triangle
     */
    @Test
    public void getNom() {
        assertEquals(triangle1.getNom(), "Triangle");
        assertEquals(triangle2.getNom(), "Triangle");
        assertEquals(triangle3.getNom(), "Triangle");
        assertEquals(triangle4.getNom(), "Triangle");
        assertEquals(triangle5.getNom(), "Triangle");
        assertEquals(triangle6.getNom(), "Triangle");
    }

    /**
     * Cette méthode permet de tester l'assignation de couleurs valides d'un triangle
     */
    @Test
    public void setCouleur() {
        for (Couleur c : Couleur.values()) {
            triangle1.setCouleur(c);
            assertEquals(triangle1.getCouleur(), c);

            triangle1.setCouleur(null);
            assertEquals(triangle1.getCouleur(), c);
        }

        triangle2.setCouleur(null);
        assertEquals(triangle2.getCouleur(), Rectangle.COULEUR_DEFAUT);
    }

    /**
     * Cette méthode permet de tester le calcul de périmètre d'un triangle
     */
    @Test
    public void calculerPerimetre() {
        assertEquals(triangle1.calculerPerimetre(), 3);
        assertEquals(triangle2.calculerPerimetre(), 7);
        assertEquals(triangle3.calculerPerimetre(), 12);
        assertEquals(triangle4.calculerPerimetre(), 16);
        assertEquals(triangle5.calculerPerimetre(), 12);
        assertEquals(triangle6.calculerPerimetre(), 32);
    }

    /**
     * Cette méthode permet de tester le calcul de surface d'un triangle
     */
    @Test
    public void calculerSurface() {
        assertEquals(triangle1.calculerSurface(), 0);
        assertEquals(triangle2.calculerSurface(), 1);
        assertEquals(triangle3.calculerSurface(), 6);
        assertEquals(triangle4.calculerSurface(), 9);
        assertEquals(triangle5.calculerSurface(), 6);
        assertEquals(triangle6.calculerSurface(), 29);
    }

    /**
     * Cette méthode permet de tester l'obtention du côté A d'un triangle
     */
    @Test
    public void getCoteA() {
        assertEquals(triangle1.getCoteA(), 1);
        assertEquals(triangle2.getCoteA(), 2);
        assertEquals(triangle3.getCoteA(), 5);
        assertEquals(triangle4.getCoteA(), 7);
        assertEquals(triangle5.getCoteA(), 3);
        assertEquals(triangle6.getCoteA(), 15);
    }

    /**
     * Cette méthode permet de tester l'obtention du côté B d'un triangle
     */
    @Test
    public void getCoteB() {
        assertEquals(triangle1.getCoteB(), 1);
        assertEquals(triangle2.getCoteB(), 2);
        assertEquals(triangle3.getCoteB(), 3);
        assertEquals(triangle4.getCoteB(), 4);
        assertEquals(triangle5.getCoteB(), 5);
        assertEquals(triangle6.getCoteB(), 9);
    }

    /**
     * Cette méthode permet de tester l'obtention du côté C d'un triangle
     */
    @Test
    public void getCoteC() {
        assertEquals(triangle1.getCoteC(), 1);
        assertEquals(triangle2.getCoteC(), 3);
        assertEquals(triangle3.getCoteC(), 4);
        assertEquals(triangle4.getCoteC(), 5);
        assertEquals(triangle5.getCoteC(), 4);
        assertEquals(triangle6.getCoteC(), 8);
    }

    /**
     * Cette méthode permet de tester l'obtention du du type d'un triangle
     */
    @Test
    public void getType() {
        assertEquals(triangle1.getType(), TypeTriangle.EQUILATERAL);
        assertEquals(triangle2.getType(), TypeTriangle.ISOCELE);
        assertEquals(triangle3.getType(), TypeTriangle.RECTANGLE);
        assertEquals(triangle4.getType(), TypeTriangle.SCALENE);
        assertEquals(triangle5.getType(), TypeTriangle.RECTANGLE);
        assertEquals(triangle6.getType(), TypeTriangle.SCALENE);
    }

    /**
     * Cette méthode permet de tester la personnalisation des informations d'un triangle
     */
    @Test
    public void testToString() {
        assertEquals(triangle1.toString(), "Triangle rouge 1, 1, 1");
        assertEquals(triangle2.toString(), "Triangle rouge 2, 2, 3");
        assertEquals(triangle3.toString(), "Triangle rouge 5, 3, 4");
        assertEquals(triangle4.toString(), "Triangle rouge 7, 4, 5");
        assertEquals(triangle5.toString(), "Triangle rouge 3, 5, 4");
        assertEquals(triangle6.toString(), "Triangle rouge 15, 9, 8");
    }
}