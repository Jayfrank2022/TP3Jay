package tests;

import exceptions.FormeException;
import formes.Forme;
import formes.VecteurFormes;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

import static org.junit.Assert.*;

/**
 * Cette classe permet de tester la classe VecteurFormes
 *
 * @author Jérémy Marceau
 */
public class VecteurFormesTest {

    private VecteurFormes vecteurFormes1;


    /**
     * Cette méthode permet de configurer les tests de classe VecteurFormes
     *
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception {
        vecteurFormes1 = new VecteurFormes();
    }

    /**
     * Cette méthode permet de tester les scénarios invalides de la classe VecteurFormes
     */
    @Test
    public void testInvalides() {
        try {
            vecteurFormes1.melanger();
            fail("Test invalide passé");

        } catch (Exception e) {
        }

        try {
            vecteurFormes1.trier();
            fail("Test invalide passé");

        } catch (Exception e) {
        }

        try {
            vecteurFormes1.toString();
            fail("Test invalide passé");

        } catch (Exception e) {
        }
    }

    /**
     * Cette méthode permet de tester l'obtention du vecteur de formes
     *
     * @throws FormeException
     */
    @Test
    public void getVecteur() throws FormeException {
        ArrayList<Forme> getVect;

        getVect = vecteurFormes1.getVecteur();
        assertTrue(getVect == null);

        vecteurFormes1.remplir(0);
        getVect = vecteurFormes1.getVecteur();
        assertTrue(getVect.isEmpty());

        vecteurFormes1.remplir(1);
        getVect = vecteurFormes1.getVecteur();
        assertTrue(getVect.size() == 1);

        vecteurFormes1.remplir(36);
        getVect = vecteurFormes1.getVecteur();
        assertTrue(getVect.size() == 36);

        vecteurFormes1.remplir(46);
        getVect = vecteurFormes1.getVecteur();
        assertTrue(getVect.size() == 46);

    }

    /**
     * Cette méthode permet de tester le mélange de vecteurs de formes
     *
     * @throws FormeException
     */
    @Test
    public void melanger() throws FormeException {
        String toStringAComparer;

        vecteurFormes1.remplir(36);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\n";
        vecteurFormes1.melanger();
        assertNotEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(12);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\n";
        vecteurFormes1.melanger();
        assertNotEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(46);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\n";
        vecteurFormes1.melanger();
        assertNotEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);
    }

    /**
     * Cette méthode permet de tester le remplissage de vecteurs de formes
     *
     * @throws FormeException
     */
    @Test
    public void remplir() throws FormeException {
        String toStringAComparer;

        vecteurFormes1.remplir(36);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(12);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(46);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);
    }

    /**
     * Cette méthode permet de tester la personnalisation des informations du vecteur de formes
     *
     * @throws FormeException
     */
    @Test
    public void testToString() throws FormeException {
        String toStringAComparer;

        vecteurFormes1.remplir(36);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(12);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(46);
        toStringAComparer = "Cercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\nRectangle jaune\nTriangle jaune\nCercle noir\nRectangle noir\nTriangle noir\nCercle orange\nRectangle orange\nTriangle orange\nCercle rouge\nRectangle rouge\nTriangle rouge\nCercle vert\nRectangle vert\nTriangle vert\nCercle bleu\nRectangle bleu\nTriangle bleu\nCercle jaune\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);
    }

    /**
     * Cette méthode permet de tester le triage de vecteurs de formes
     *
     * @throws FormeException
     */
    @Test
    public void trier() throws FormeException {
        String toStringAComparer;

        vecteurFormes1.remplir(36);
        vecteurFormes1.trier();
        toStringAComparer = "Cercle bleu\nCercle bleu\nCercle jaune\nCercle jaune\nCercle noir\nCercle noir\nCercle orange\nCercle orange\nCercle rouge\nCercle rouge\nCercle vert\nCercle vert\nRectangle bleu\nRectangle bleu\nRectangle jaune\nRectangle jaune\nRectangle noir\nRectangle noir\nRectangle orange\nRectangle orange\nRectangle rouge\nRectangle rouge\nRectangle vert\nRectangle vert\nTriangle bleu\nTriangle bleu\nTriangle jaune\nTriangle jaune\nTriangle noir\nTriangle noir\nTriangle orange\nTriangle orange\nTriangle rouge\nTriangle rouge\nTriangle vert\nTriangle vert\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(36);
        vecteurFormes1.melanger();
        vecteurFormes1.trier();
        toStringAComparer = "Cercle bleu\nCercle bleu\nCercle jaune\nCercle jaune\nCercle noir\nCercle noir\nCercle orange\nCercle orange\nCercle rouge\nCercle rouge\nCercle vert\nCercle vert\nRectangle bleu\nRectangle bleu\nRectangle jaune\nRectangle jaune\nRectangle noir\nRectangle noir\nRectangle orange\nRectangle orange\nRectangle rouge\nRectangle rouge\nRectangle vert\nRectangle vert\nTriangle bleu\nTriangle bleu\nTriangle jaune\nTriangle jaune\nTriangle noir\nTriangle noir\nTriangle orange\nTriangle orange\nTriangle rouge\nTriangle rouge\nTriangle vert\nTriangle vert\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(12);
        vecteurFormes1.trier();
        toStringAComparer = "Cercle bleu\nCercle jaune\nCercle rouge\nCercle vert\nRectangle bleu\nRectangle jaune\nRectangle rouge\nRectangle vert\nTriangle bleu\nTriangle jaune\nTriangle rouge\nTriangle vert\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);

        vecteurFormes1.remplir(12);
        vecteurFormes1.melanger();
        vecteurFormes1.trier();
        toStringAComparer = "Cercle bleu\nCercle jaune\nCercle rouge\nCercle vert\nRectangle bleu\nRectangle jaune\nRectangle rouge\nRectangle vert\nTriangle bleu\nTriangle jaune\nTriangle rouge\nTriangle vert\n";
        assertEquals(vecteurFormes1.toString().compareTo(toStringAComparer), 0);
    }
}